from __future__ import annotations

import base64
import threading
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import uvicorn

from .core import AppConfig, ConfigStore, GenerationOptions, HistoryStore, ImageApiClient, make_grid


class GenerateBody(BaseModel):
    prompt: str = Field(min_length=1, max_length=20_000)
    model: str | None = None
    style: str = "无"
    aspect_ratio: str = "Auto"
    resolution: str = "1K"
    count: int = Field(default=1, ge=1, le=25)
    output_dir: str | None = None
    source_image: str | None = None


class TextureBody(GenerateBody):
    texture_size: int = Field(default=32, ge=16, le=512)


class BatchBody(BaseModel):
    prompts: list[str] = Field(min_length=1, max_length=25)
    model: str | None = None
    style: str = "无"
    output_dir: str | None = None


class GridBody(BatchBody):
    columns: int = Field(default=5, ge=1, le=10)
    gap: int = Field(default=4, ge=0, le=128)
    background: str = "#151515"
    border: bool = True


def encode_result(paths: list[Path], include_base64: bool = True) -> dict[str, Any]:
    return {
        "status": "ok",
        "images": [
            {
                "path": str(path),
                "base64": base64.b64encode(path.read_bytes()).decode("ascii") if include_base64 else None,
            }
            for path in paths
        ],
    }


def create_app(config_store: ConfigStore, history: HistoryStore) -> FastAPI:
    app = FastAPI(title="UltraTexture Studio MCP Bridge", version="1.0.0", description="本地图片生成、批量生成、拼图与 MC 纹理服务。")

    def generate(body: GenerateBody, mode: str = "image") -> list[Path]:
        config = config_store.load()
        options = GenerationOptions(
            prompt=body.prompt,
            model=body.model or config.model,
            aspect_ratio=body.aspect_ratio,
            resolution=body.resolution,
            style=body.style,
            count=body.count,
            mode=mode,
            texture_size=getattr(body, "texture_size", 32),
            output_dir=body.output_dir or config.output_dir,
            source_image=body.source_image or "",
        )
        paths = ImageApiClient(config).generate(options)
        for path in paths:
            history.add(options.prompt, {"mode": mode, "style": options.style, "model": options.model}, path)
        return paths

    @app.get("/health")
    def health() -> dict[str, Any]:
        config = config_store.load()
        return {"status": "ok", "service": "UltraTexture Studio", "port": config.mcp_port}

    @app.post("/generate")
    def generate_route(body: GenerateBody) -> dict[str, Any]:
        try:
            return encode_result(generate(body))
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, str(exc)) from exc

    @app.post("/generate_texture")
    def texture_route(body: TextureBody) -> dict[str, Any]:
        try:
            return encode_result(generate(body, "texture"))
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, str(exc)) from exc

    @app.post("/generate_batch")
    def batch_route(body: BatchBody) -> dict[str, Any]:
        paths: list[Path] = []
        try:
            for prompt in body.prompts:
                paths.extend(generate(GenerateBody(prompt=prompt, model=body.model, style=body.style, output_dir=body.output_dir)))
            return encode_result(paths)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, str(exc)) from exc

    @app.post("/generate_grid")
    def grid_route(body: GridBody) -> dict[str, Any]:
        try:
            paths: list[Path] = []
            for prompt in body.prompts:
                paths.extend(generate(GenerateBody(prompt=prompt, model=body.model, style=body.style, output_dir=body.output_dir)))
            target = Path(body.output_dir or config_store.load().output_dir) / "grid.png"
            grid = make_grid(paths, target, body.columns, body.gap, body.background, body.border)
            return encode_result([grid])
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, str(exc)) from exc

    @app.post("/mcp")
    def mcp_route(payload: dict[str, Any]) -> dict[str, Any]:
        """Small JSON-RPC MCP bridge for local Codex integrations."""
        method = payload.get("method")
        request_id = payload.get("id")
        if method == "initialize":
            result = {
                "protocolVersion": "2025-03-26",
                "serverInfo": {"name": "UltraTexture Studio", "version": "1.0.0"},
                "capabilities": {"tools": {}},
            }
        elif method == "tools/list":
            result = {
                "tools": [
                    {
                        "name": "generate",
                        "description": "使用已配置的图片 API 生成一张或多张图片。",
                        "inputSchema": GenerateBody.model_json_schema(),
                    },
                    {
                        "name": "generate_texture",
                        "description": "生成并缩放为 Minecraft 像素贴图的 PNG。",
                        "inputSchema": TextureBody.model_json_schema(),
                    },
                    {
                        "name": "generate_batch",
                        "description": "使用一组提示词批量生成图片。",
                        "inputSchema": BatchBody.model_json_schema(),
                    },
                    {
                        "name": "generate_grid",
                        "description": "批量生成图片并拼接为网格 PNG。",
                        "inputSchema": GridBody.model_json_schema(),
                    },
                ]
            }
        elif method == "tools/call":
            arguments = payload.get("params", {}).get("arguments", {})
            tool_name = payload.get("params", {}).get("name", "")
            try:
                if tool_name == "generate":
                    result_data = encode_result(generate(GenerateBody(**arguments)))
                elif tool_name == "generate_texture":
                    result_data = encode_result(generate(TextureBody(**arguments), "texture"))
                elif tool_name == "generate_batch":
                    body = BatchBody(**arguments)
                    generated: list[Path] = []
                    for prompt in body.prompts:
                        generated.extend(
                            generate(GenerateBody(prompt=prompt, model=body.model, style=body.style, output_dir=body.output_dir))
                        )
                    result_data = encode_result(generated)
                elif tool_name == "generate_grid":
                    body = GridBody(**arguments)
                    generated = []
                    for prompt in body.prompts:
                        generated.extend(
                            generate(GenerateBody(prompt=prompt, model=body.model, style=body.style, output_dir=body.output_dir))
                        )
                    target = Path(body.output_dir or config_store.load().output_dir) / "grid.png"
                    result_data = encode_result([make_grid(generated, target, body.columns, body.gap, body.background, body.border)])
                else:
                    raise ValueError(f"未知工具：{tool_name}")
                result = {"content": [{"type": "text", "text": __import__("json").dumps(result_data, ensure_ascii=False)}]}
            except Exception as exc:  # noqa: BLE001
                result = {"content": [{"type": "text", "text": f"生成失败：{exc}"}], "isError": True}
        else:
            result = {"error": "请调用 initialize、tools/list 或 tools/call。"}
        return {"jsonrpc": "2.0", "id": request_id, "result": result}

    return app


class McpService:
    def __init__(self, config_store: ConfigStore, history: HistoryStore) -> None:
        self._config_store = config_store
        self._history = history
        self._thread: threading.Thread | None = None
        self._server: uvicorn.Server | None = None

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def start(self, port: int) -> None:
        if self.running:
            return
        app = create_app(self._config_store, self._history)
        self._server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
        self._thread = threading.Thread(target=self._server.run, daemon=True, name="UltraTextureMCP")
        self._thread.start()

    def stop(self) -> None:
        if self._server:
            self._server.should_exit = True
