"""UltraTexture Studio application package."""
