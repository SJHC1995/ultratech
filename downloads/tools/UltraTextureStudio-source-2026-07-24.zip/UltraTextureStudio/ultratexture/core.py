from __future__ import annotations

import base64
import csv
import io
import json
import logging
import re
import sqlite3
import sys
import threading
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

import requests
from PIL import Image, ImageColor, ImageOps


APP_NAME = "UltraTexture Studio"
APP_DIR = Path.home() / "AppData" / "Roaming" / "UltraTextureStudio"
CONFIG_PATH = APP_DIR / "config.json"
DATABASE_PATH = APP_DIR / "history.sqlite3"
LOG_PATH = APP_DIR / "logs" / "ultratexture.log"
LEGACY_OUTPUT_DIR = str(Path.home() / "Pictures" / "UltraTexture Studio")
DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)

DEFAULT_STYLES = {
    "无": "",
    "写实": "photorealistic, cinematic lighting, highly detailed",
    "卡通": "clean cartoon illustration, expressive shapes, polished colors",
    "像素风": "crisp pixel art, limited color palette, intentional dithering",
    "MC 风格": "Minecraft resource-pack style, blocky voxel aesthetic, readable pixel texture",
    "赛博朋克": "cyberpunk industrial neon, teal and magenta glow, high contrast",
    "水彩": "watercolor painting, soft pigments, textured paper",
    "油画": "classical oil painting, visible brush strokes, dramatic composition",
    "低多边形": "low-poly 3D render, clean faceted geometry, game asset presentation",
    "工业蓝图": "industrial blueprint sheet, technical line art, annotations-free",
    "黑暗科幻": "dark science-fiction industry, dense machinery, controlled emissive lighting",
}

MC_GUI_TEMPLATES = {
    "机器界面": "Minecraft machine GUI texture, industrial frame, item slots, progress bar, no text",
    "背包": "Minecraft inventory GUI texture, player inventory slots, parchment and steel framing, no text",
    "熔炉": "Minecraft furnace GUI texture, fuel slot, input slot, output slot, heat progress indicator, no text",
    "工作台": "Minecraft crafting table GUI texture, 3 by 3 crafting slots, output slot, no text",
    "自定义": "Minecraft GUI texture, industrial panel, slots, buttons and progress indicators, no text",
}


def application_dir() -> Path:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    return APP_DIR


def installation_dir() -> Path:
    """Return the directory containing the source launcher or packaged EXE."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


def default_output_dir() -> str:
    """Generated assets stay beside the installed application by default."""
    return str(installation_dir() / ".cache")


def configure_logging() -> None:
    application_dir()
    logging.basicConfig(
        filename=LOG_PATH,
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        encoding="utf-8",
    )


@dataclass
class AppConfig:
    api_key: str = ""
    api_base_url: str = "https://api.openai.com/v1/images/generations"
    model: str = "gpt-image-1"
    output_dir: str = field(default_factory=default_output_dir)
    proxy: str = ""
    user_agent: str = DEFAULT_USER_AGENT
    api_profile: str = "openai"
    mcp_enabled: bool = True
    mcp_port: int = 8765
    templates: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_STYLES))


class ConfigStore:
    def load(self) -> AppConfig:
        application_dir()
        if not CONFIG_PATH.exists():
            config = AppConfig()
            self.save(config)
            return config
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            defaults = asdict(AppConfig())
            defaults.update(data)
            config = AppConfig(**defaults)
            # Seamlessly migrate the former default without changing a user-selected path.
            if config.output_dir == LEGACY_OUTPUT_DIR:
                config.output_dir = default_output_dir()
                self.save(config)
            return config
        except Exception:  # noqa: BLE001
            logging.exception("Unable to load config")
            return AppConfig()

    def save(self, config: AppConfig) -> None:
        application_dir()
        CONFIG_PATH.write_text(json.dumps(asdict(config), ensure_ascii=False, indent=2), encoding="utf-8")


class HistoryStore:
    def __init__(self) -> None:
        application_dir()
        self._connection = sqlite3.connect(DATABASE_PATH, check_same_thread=False)
        self._lock = threading.Lock()
        with self._connection:
            self._connection.execute(
                """
                CREATE TABLE IF NOT EXISTS history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    prompt TEXT NOT NULL,
                    params_json TEXT NOT NULL,
                    image_path TEXT NOT NULL
                )
                """
            )

    def add(self, prompt: str, params: dict[str, Any], image_path: Path) -> None:
        with self._lock, self._connection:
            self._connection.execute(
                "INSERT INTO history (created_at, prompt, params_json, image_path) VALUES (?, ?, ?, ?)",
                (datetime.now().isoformat(timespec="seconds"), prompt, json.dumps(params, ensure_ascii=False), str(image_path)),
            )

    def list(self, limit: int = 120) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._connection.execute(
                "SELECT id, created_at, prompt, params_json, image_path FROM history ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [
            {"id": row[0], "created_at": row[1], "prompt": row[2], "params": json.loads(row[3]), "image_path": row[4]}
            for row in rows
        ]

    def delete(self, row_id: int) -> None:
        with self._lock, self._connection:
            self._connection.execute("DELETE FROM history WHERE id = ?", (row_id,))

    def export_json(self, target: Path) -> None:
        target.write_text(json.dumps(self.list(10_000), ensure_ascii=False, indent=2), encoding="utf-8")

    def export_csv(self, target: Path) -> None:
        with target.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.DictWriter(file, fieldnames=["id", "created_at", "prompt", "image_path", "params"])
            writer.writeheader()
            writer.writerows(self.list(10_000))


@dataclass
class GenerationOptions:
    prompt: str
    model: str
    aspect_ratio: str = "Auto"
    resolution: str = "1K"
    style: str = "无"
    count: int = 1
    mode: str = "image"
    texture_size: int = 32
    custom_size: str = ""
    output_dir: str = ""
    source_image: str = ""


def normalize_endpoint(base_url: str) -> str:
    value = base_url.strip().rstrip("/")
    if value.endswith("/images/generations"):
        return value
    if value.endswith("/v1"):
        return f"{value}/images/generations"
    return f"{value}/v1/images/generations"


def normalize_edit_endpoint(base_url: str) -> str:
    """Derive the OpenAI-compatible image-edit endpoint from a configured API URL."""
    value = base_url.strip().rstrip("/")
    if value.endswith("/images/generations"):
        return f"{value.rsplit('/', 1)[0]}/edits"
    if value.endswith("/images/edits"):
        return value
    if value.endswith("/v1"):
        return f"{value}/images/edits"
    return f"{value}/v1/images/edits"


def output_size(options: GenerationOptions) -> str:
    if options.mode == "texture":
        return "1024x1024"
    if options.custom_size:
        return options.custom_size
    mapping = {
        ("Auto", "1K"): "1024x1024",
        ("1:1", "1K"): "1024x1024",
        ("9:16", "1K"): "1024x1536",
        ("16:9", "1K"): "1536x1024",
        ("4:3", "1K"): "1024x1024",
        ("3:4", "1K"): "1024x1024",
        ("1:1", "2K"): "2048x2048",
        ("1:1", "4K"): "4096x4096",
        ("1:1", "8K"): "8192x8192",
    }
    return mapping.get((options.aspect_ratio, options.resolution), "1024x1024")


def compose_prompt(options: GenerationOptions, templates: dict[str, str]) -> str:
    prompt = options.prompt.strip()
    suffix = templates.get(options.style, "")
    if options.mode == "texture":
        suffix = (
            f"Minecraft resource-pack texture, exact {options.texture_size}x{options.texture_size} pixel-art target, "
            "tileable where appropriate, crisp blocks of color, no text, no border"
        )
    if suffix:
        prompt = f"{prompt}\n\nStyle requirements: {suffix}"
    return prompt


def safe_filename(value: str, fallback: str = "texture") -> str:
    """Create a Windows-safe, readable filename stem from user-entered text."""
    cleaned = re.sub(r'[\\/:*?"<>|\r\n]+', "_", value.strip())
    cleaned = re.sub(r"\s+", "_", cleaned).strip("._ ")
    return (cleaned[:72] or fallback)


class ImageApiClient:
    def __init__(self, config: AppConfig) -> None:
        self.config = config

    def uses_aimami_profile(self) -> bool:
        """AiMaMi's image API uses a minimal JSON body and data-URL img2img field."""
        return self.config.api_profile == "aimami" or urlparse(self.config.api_base_url).netloc == "api.iiiiitoken.com"

    def generate(
        self,
        options: GenerationOptions,
        report_progress: Callable[[int, str], None] | None = None,
    ) -> list[Path]:
        def report(percent: int, message: str) -> None:
            if report_progress:
                report_progress(max(0, min(100, percent)), message)

        if not self.config.api_key:
            raise RuntimeError("未配置 API Key。请点击右上角设置。")
        if not options.prompt.strip():
            raise RuntimeError("请输入图片描述。")

        report(4, "正在校验生成参数")
        target_dir = Path(options.output_dir or self.config.output_dir)
        target_dir.mkdir(parents=True, exist_ok=True)
        prompt = compose_prompt(options, self.config.templates)
        payload: dict[str, Any] = {
            "model": options.model or self.config.model,
            "prompt": prompt,
            "n": max(1, min(options.count, 25)),
            "size": output_size(options),
        }
        if not self.uses_aimami_profile():
            payload["response_format"] = "b64_json"
        proxies = {"http": self.config.proxy, "https": self.config.proxy} if self.config.proxy else None
        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "User-Agent": self.config.user_agent.strip() or DEFAULT_USER_AGENT,
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        }
        report(12, "正在连接图像服务")
        if options.source_image:
            source = Path(options.source_image)
            if not source.is_file():
                raise RuntimeError(f"参考图片不存在：{source}")
            if self.uses_aimami_profile():
                # The AiMaMi declaration sends img2img to the same generation route as
                # text-to-image, with an `image` data URL in the JSON request body.
                mime = {
                    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
                    ".bmp": "image/bmp",
                }.get(source.suffix.lower(), "image/png")
                payload["image"] = f"data:{mime};base64,{base64.b64encode(source.read_bytes()).decode('ascii')}"
                response = requests.post(
                    normalize_endpoint(self.config.api_base_url),
                    headers={**headers, "Content-Type": "application/json"},
                    json=payload,
                    timeout=240,
                    proxies=proxies,
                )
            else:
                # Standard OpenAI-compatible image-to-image APIs use multipart /images/edits.
                # The API Base URL remains a single setting; the edit route is derived from it.
                with source.open("rb") as source_file:
                    response = requests.post(
                        normalize_edit_endpoint(self.config.api_base_url),
                        headers=headers,
                        data=payload,
                        files={"image": (source.name, source_file, "image/png")},
                        timeout=240,
                        proxies=proxies,
                    )
        else:
            response = requests.post(
                normalize_endpoint(self.config.api_base_url),
                headers={**headers, "Content-Type": "application/json"},
                json=payload,
                timeout=240,
                proxies=proxies,
            )
        report(72, "图像服务已返回，正在解析结果")
        if not response.ok:
            try:
                detail = response.json().get("error", {}).get("message", response.text)
            except ValueError:
                detail = response.text
            if response.status_code == 403 and "no access to model" in detail.lower():
                raise RuntimeError(
                    f"模型无权限：当前 API Key 无权使用“{options.model}”。\n\n"
                    "请点击右上角“设置”，将“默认模型”改为你的服务商账号已开通的模型"
                    "（例如 gpt-image-1），或在模型下拉框输入该服务商提供的模型名称后重试。"
                )
            cloudflare_markers = ("cloudflare", "cf-ray", "attention required", "just a moment")
            if response.status_code == 403 and any(marker in detail.lower() for marker in cloudflare_markers):
                raise RuntimeError(
                    "上游 Cloudflare 拦截了请求（HTTP 403）。\n\n"
                    "程序已传递 User-Agent。请在“设置 → User-Agent”中填写上游服务商要求的值，"
                    "并确认 API Base URL 是服务商提供的 API 地址而非网页地址。"
                )
            raise RuntimeError(f"图像服务返回 HTTP {response.status_code}：{detail[:1200]}")
        body = response.json()
        results = body.get("data", [])
        if not results:
            raise RuntimeError("服务未返回图片。请检查模型、接口格式和配额。")

        created: list[Path] = []
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        stem = "mc_texture" if options.mode == "texture" else "image"
        for index, item in enumerate(results, 1):
            report(75 + int((index - 1) / max(1, len(results)) * 20), f"正在处理图片 {index}/{len(results)}")
            if item.get("b64_json"):
                data = base64.b64decode(item["b64_json"])
            elif item.get("url"):
                image_response = requests.get(item["url"], timeout=180, proxies=proxies)
                image_response.raise_for_status()
                data = image_response.content
            else:
                raise RuntimeError("返回条目未包含 b64_json 或 url。")
            if options.mode == "texture":
                # Providers commonly only support large generation sizes. Resize locally so the
                # exported resource can be dropped directly into a Minecraft resource pack.
                texture_name = safe_filename(options.prompt, "mc_texture")
                suffix = "" if len(results) == 1 else f"_{index}"
                path = target_dir / f"{texture_name}_{options.texture_size}{suffix}.png"
                with Image.open(io.BytesIO(data)) as generated:
                    generated.convert("RGBA").resize(
                        (options.texture_size, options.texture_size),
                        Image.Resampling.NEAREST,
                    ).save(path)
            else:
                path = target_dir / f"{stem}_{stamp}_{index}.png"
                path.write_bytes(data)
            created.append(path)
        report(100, f"已完成 {len(created)} 张图片")
        return created


def make_grid(images: list[Path], target: Path, columns: int = 5, gap: int = 4, background: str = "#151515", border: bool = True) -> Path:
    if not images:
        raise RuntimeError("没有可拼接的图片。")
    loaded = [Image.open(path).convert("RGBA") for path in images]
    cell_width = max(image.width for image in loaded)
    cell_height = max(image.height for image in loaded)
    rows = (len(loaded) + columns - 1) // columns
    canvas = Image.new("RGBA", (columns * cell_width + (columns + 1) * gap, rows * cell_height + (rows + 1) * gap), ImageColor.getrgb(background))
    for index, image in enumerate(loaded):
        x = gap + (index % columns) * (cell_width + gap)
        y = gap + (index // columns) * (cell_height + gap)
        fitted = ImageOps.contain(image, (cell_width, cell_height))
        canvas.alpha_composite(fitted, (x + (cell_width - fitted.width) // 2, y + (cell_height - fitted.height) // 2))
        if border:
            from PIL import ImageDraw

            ImageDraw.Draw(canvas).rectangle((x, y, x + cell_width - 1, y + cell_height - 1), outline="#88d9ff", width=1)
    target.parent.mkdir(parents=True, exist_ok=True)
    canvas.convert("RGB").save(target)
    return target
