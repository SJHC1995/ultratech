from __future__ import annotations

import csv
import json
from pathlib import Path

from PySide6.QtCore import QObject, QThread, Qt, QUrl, Signal, Slot
from PySide6.QtGui import QAction, QDesktopServices, QIcon, QPixmap, QWheelEvent
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QColorDialog, QComboBox, QDialog, QFileDialog, QFormLayout,
    QFrame, QGraphicsPixmapItem, QGraphicsScene, QGraphicsView, QGridLayout, QHBoxLayout,
    QInputDialog, QLabel, QLineEdit, QListWidget, QMainWindow, QMessageBox, QPlainTextEdit,
    QProgressBar, QPushButton, QScrollArea, QSpinBox, QSplitter, QStatusBar, QTabWidget, QToolBar,
    QVBoxLayout, QWidget,
)

from .core import (
    APP_NAME, AppConfig, ConfigStore, GenerationOptions, HistoryStore, ImageApiClient, MC_GUI_TEMPLATES,
    make_grid,
)
from .mcp_service import McpService


class Worker(QObject):
    done = Signal(list)
    error = Signal(str)
    finished = Signal()
    progress = Signal(int, str)

    def __init__(self, task) -> None:
        super().__init__()
        self.task = task

    @Slot()
    def run(self) -> None:
        try:
            self.done.emit(self.task(lambda percent, message: self.progress.emit(percent, message)))
        except Exception as exc:  # noqa: BLE001
            self.error.emit(str(exc))
        finally:
            self.finished.emit()


class ImageCanvas(QGraphicsView):
    def __init__(self) -> None:
        super().__init__()
        self.scene = QGraphicsScene(self)
        self.item = QGraphicsPixmapItem()
        self.scene.addItem(self.item)
        self.setScene(self.scene)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setRenderHints(self.renderHints())
        self.setBackgroundBrush(Qt.GlobalColor.transparent)
        self._scale = 1.0

    def show_path(self, path: Path) -> None:
        pixmap = QPixmap(str(path))
        self.item.setPixmap(pixmap)
        self.scene.setSceneRect(pixmap.rect())
        self.resetTransform()
        self._scale = 1.0
        self.fitInView(self.scene.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)

    def wheelEvent(self, event: QWheelEvent) -> None:
        if self.item.pixmap().isNull():
            return
        factor = 1.18 if event.angleDelta().y() > 0 else 0.85
        self._scale = max(0.1, min(12, self._scale * factor))
        self.scale(factor, factor)


class SettingsDialog(QDialog):
    def __init__(self, config: AppConfig, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("设置")
        self.setMinimumWidth(520)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.key = QLineEdit(config.api_key)
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.url = QLineEdit(config.api_base_url)
        self.model = QLineEdit(config.model)
        self.api_profile = QComboBox()
        self.api_profile.addItem("OpenAI 标准（图生图 /images/edits）", "openai")
        self.api_profile.addItem("AiMaMi 兼容（最简 JSON / image data URL）", "aimami")
        self.api_profile.setCurrentIndex(1 if config.api_profile == "aimami" else 0)
        self.output = QLineEdit(config.output_dir)
        self.proxy = QLineEdit(config.proxy)
        self.user_agent = QLineEdit(config.user_agent)
        self.mcp = QCheckBox("启动 UltraTexture MCP 本地服务")
        self.mcp.setChecked(config.mcp_enabled)
        self.port = QSpinBox()
        self.port.setRange(1024, 65535)
        self.port.setValue(config.mcp_port)
        form.addRow("API Key", self.key)
        form.addRow("API Base URL", self.url)
        form.addRow("默认模型", self.model)
        form.addRow("请求兼容模式", self.api_profile)
        form.addRow("默认输出目录", self.output)
        form.addRow("HTTP/HTTPS 代理（可选）", self.proxy)
        form.addRow("User-Agent", self.user_agent)
        form.addRow("", self.mcp)
        form.addRow("MCP 端口", self.port)
        layout.addLayout(form)
        buttons = QHBoxLayout()
        buttons.addStretch()
        cancel = QPushButton("取消")
        save = QPushButton("保存")
        cancel.clicked.connect(self.reject)
        save.clicked.connect(self.accept)
        buttons.addWidget(cancel)
        buttons.addWidget(save)
        layout.addLayout(buttons)

    def apply_to(self, config: AppConfig) -> None:
        config.api_key = self.key.text().strip()
        config.api_base_url = self.url.text().strip()
        config.model = self.model.text().strip()
        config.api_profile = self.api_profile.currentData()
        config.output_dir = self.output.text().strip()
        config.proxy = self.proxy.text().strip()
        config.user_agent = self.user_agent.text().strip()
        config.mcp_enabled = self.mcp.isChecked()
        config.mcp_port = self.port.value()


class TemplateDialog(QDialog):
    def __init__(self, config: AppConfig, parent=None) -> None:
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("预制模板编辑")
        self.resize(620, 420)
        layout = QHBoxLayout(self)
        self.list = QListWidget()
        self.list.addItems(config.templates.keys())
        self.text = QPlainTextEdit()
        self.list.currentTextChanged.connect(self._load)
        layout.addWidget(self.list, 1)
        right = QVBoxLayout()
        right.addWidget(self.text, 1)
        add = QPushButton("新增")
        delete = QPushButton("删除")
        save = QPushButton("保存")
        add.clicked.connect(self._add)
        delete.clicked.connect(self._delete)
        save.clicked.connect(self.accept)
        right.addWidget(add)
        right.addWidget(delete)
        right.addWidget(save)
        layout.addLayout(right, 2)
        if self.list.count():
            self.list.setCurrentRow(0)

    def _load(self, name: str) -> None:
        self.text.setPlainText(self.config.templates.get(name, ""))

    def _add(self) -> None:
        name, ok = QInputDialog.getText(self, "新增模板", "模板名称")
        if ok and name.strip() and name.strip() not in self.config.templates:
            self.config.templates[name.strip()] = ""
            self.list.addItem(name.strip())
            self.list.setCurrentRow(self.list.count() - 1)

    def _delete(self) -> None:
        name = self.list.currentItem().text() if self.list.currentItem() else ""
        if name and QMessageBox.question(self, "删除模板", f"删除“{name}”？") == QMessageBox.StandardButton.Yes:
            self.config.templates.pop(name, None)
            self.list.takeItem(self.list.currentRow())

    def accept(self) -> None:
        if self.list.currentItem():
            self.config.templates[self.list.currentItem().text()] = self.text.toPlainText().strip()
        super().accept()


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.config_store = ConfigStore()
        self.config = self.config_store.load()
        self.history = HistoryStore()
        self.mcp = McpService(self.config_store, self.history)
        self.thread: QThread | None = None
        self.worker: Worker | None = None
        self.generated: list[Path] = []

        self.setWindowTitle("UltraTexture Studio")
        self.resize(1460, 930)
        self.setMinimumSize(1180, 760)
        self._build_menu()
        self._build_ui()
        self._start_mcp_if_enabled()

    def _build_menu(self) -> None:
        menu = self.menuBar()
        file_menu = menu.addMenu("文件")
        file_menu.addAction("导入提示词列表", self.import_prompts)
        file_menu.addAction("导出历史 JSON", self.export_history_json)
        file_menu.addAction("导出历史 CSV", self.export_history_csv)
        file_menu.addSeparator()
        file_menu.addAction("退出", self.close)
        edit_menu = menu.addMenu("编辑")
        edit_menu.addAction("编辑预制模板", self.edit_templates)
        view_menu = menu.addMenu("视图")
        view_menu.addAction("刷新历史", self.refresh_history)
        help_menu = menu.addMenu("帮助")
        help_menu.addAction("打开 MCP 文档", lambda: QDesktopServices.openUrl(QUrl(f"http://127.0.0.1:{self.config.mcp_port}/docs")))

        toolbar = QToolBar("快速操作")
        toolbar.setMovable(False)
        toolbar.addAction("生成", self.generate_current)
        toolbar.addAction("保存预览", self.save_current_preview)
        toolbar.addAction("清空预览", self.clear_preview)
        toolbar.addSeparator()
        settings_action = QAction("⚙ 设置", self)
        settings_action.triggered.connect(self.open_settings)
        toolbar.addAction(settings_action)
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea, toolbar)

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(16, 16, 16, 16)
        app_header = QHBoxLayout()
        brand = QLabel("UltraTexture Studio")
        brand.setObjectName("appBrand")
        subtitle = QLabel("MINECRAFT TEXTURE · IMAGE FORGE")
        subtitle.setObjectName("appSubtitle")
        settings_button = QPushButton("⚙ 设置")
        settings_button.setObjectName("settingsButton")
        settings_button.clicked.connect(self.open_settings)
        app_header.addWidget(brand)
        app_header.addWidget(subtitle)
        app_header.addStretch()
        app_header.addWidget(settings_button)
        layout.addLayout(app_header)
        splitter = QSplitter()
        layout.addWidget(splitter)

        left = QFrame()
        left.setObjectName("leftPanel")
        left_layout = QVBoxLayout(left)
        header = QLabel("图片生成器")
        header.setObjectName("panelTitle")
        left_layout.addWidget(header)

        self.mode_tabs = QTabWidget()
        self.mode_tabs.addTab(self._build_generate_tab(), "文生图")
        self.mode_tabs.addTab(self._build_image_to_image_tab(), "图生图")
        self.mode_tabs.addTab(self._build_texture_tab(), "MC 纹理")
        self.mode_tabs.addTab(self._build_batch_tab(), "批量 / 拼图")
        self.mode_tabs.addTab(self._build_gui_tab(), "MC GUI")
        left_layout.addWidget(self.mode_tabs)
        splitter.addWidget(left)

        right = QFrame()
        right.setObjectName("rightPanel")
        right_layout = QVBoxLayout(right)
        preview_title = QLabel("▧ 图片预览")
        preview_title.setObjectName("panelTitle")
        right_layout.addWidget(preview_title)
        self.canvas = ImageCanvas()
        right_layout.addWidget(self.canvas, 1)
        self.thumb_area = QScrollArea()
        self.thumb_area.setWidgetResizable(True)
        self.thumb_container = QWidget()
        self.thumb_layout = QGridLayout(self.thumb_container)
        self.thumb_area.setWidget(self.thumb_container)
        self.thumb_area.setMaximumHeight(190)
        right_layout.addWidget(self.thumb_area)
        history_title = QLabel("历史记录")
        history_title.setObjectName("sectionTitle")
        right_layout.addWidget(history_title)
        self.history_list = QListWidget()
        self.history_list.setMaximumHeight(150)
        self.history_list.itemClicked.connect(self._history_clicked)
        right_layout.addWidget(self.history_list)
        splitter.addWidget(right)
        splitter.setSizes([510, 920])

        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.progress_label = QLabel("就绪")
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedWidth(220)
        self.progress_bar.setFormat("%p%")
        self.status.addPermanentWidget(self.progress_label)
        self.status.addPermanentWidget(self.progress_bar)
        self.refresh_history()
        self._apply_theme()

    def _build_generate_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        self.prompt = QPlainTextEdit()
        self.prompt.setPlaceholderText("描述您的图片（最多 20000 字符）")
        self.prompt.textChanged.connect(lambda: self.count_label.setText(f"{len(self.prompt.toPlainText())} / 20000"))
        self.count_label = QLabel("0 / 20000")
        layout.addWidget(QLabel("描述您的图片"))
        layout.addWidget(self.prompt)
        layout.addWidget(self.count_label)
        self.model = QComboBox()
        self.model.setEditable(True)
        models = ["gpt-image-1", "GPT-Image-2", "DALL-E 3", "Stable Diffusion XL"]
        if self.config.model not in models:
            models.insert(0, self.config.model)
        self.model.addItems(models)
        self.model.setCurrentText(self.config.model)
        self.aspect = QComboBox()
        self.aspect.addItems(["Auto", "1:1", "9:16", "16:9", "4:3", "3:4"])
        self.resolution = QComboBox()
        self.resolution.addItems(["1K", "2K", "4K", "8K"])
        self.custom_size = QLineEdit()
        self.custom_size.setPlaceholderText("例如 1024x1024（留空则使用预设）")
        self.style = QComboBox()
        self.style.addItems(self.config.templates.keys())
        form = QFormLayout()
        form.addRow("模型", self.model)
        form.addRow("宽高比", self.aspect)
        form.addRow("分辨率", self.resolution)
        form.addRow("自定义尺寸", self.custom_size)
        form.addRow("风格预制", self.style)
        layout.addLayout(form)
        button = QPushButton("生成图片")
        button.setObjectName("primaryButton")
        button.clicked.connect(self.generate_current)
        layout.addWidget(button)
        layout.addStretch()
        return page

    def _build_texture_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        self.texture_prompt = QPlainTextEdit()
        self.texture_prompt.setPlaceholderText("例如：红色羊毛纹理、草地侧面、磨损石砖")
        self.texture_size = QComboBox()
        self.texture_size.addItems(["16", "32", "64"])
        form = QFormLayout()
        form.addRow("纹理描述", self.texture_prompt)
        form.addRow("目标尺寸", self.texture_size)
        layout.addLayout(form)
        button = QPushButton("生成 MC 贴图")
        button.setObjectName("primaryButton")
        button.clicked.connect(self.generate_texture)
        layout.addWidget(button)
        layout.addStretch()
        return page

    def _build_image_to_image_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(QLabel("参考图片"))
        source_row = QHBoxLayout()
        self.img2img_source = QLineEdit()
        self.img2img_source.setPlaceholderText("选择要重绘、扩展或改造的本地图片")
        browse = QPushButton("选择图片")
        browse.clicked.connect(self.choose_img2img_source)
        source_row.addWidget(self.img2img_source, 1)
        source_row.addWidget(browse)
        layout.addLayout(source_row)
        layout.addWidget(QLabel("重绘描述"))
        self.img2img_prompt = QPlainTextEdit()
        self.img2img_prompt.setPlaceholderText("例如：保持轮廓，将其改造成 Minecraft 工业机器方块纹理")
        layout.addWidget(self.img2img_prompt)
        layout.addWidget(QLabel("图生图将调用 OpenAI 兼容的 /v1/images/edits 接口；接口需支持 multipart 图片上传。"))
        button = QPushButton("根据参考图生成")
        button.setObjectName("primaryButton")
        button.clicked.connect(self.generate_image_to_image)
        layout.addWidget(button)
        layout.addStretch()
        return page

    def _build_batch_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        self.batch_prompts = QPlainTextEdit()
        self.batch_prompts.setPlaceholderText("每行一条描述；最多 25 条。也可从 CSV/JSON 导入。")
        layout.addWidget(self.batch_prompts)
        row = QHBoxLayout()
        self.batch_grid = QCheckBox("拼图生成（5×5）")
        self.grid_gap = QSpinBox()
        self.grid_gap.setRange(0, 128)
        self.grid_gap.setValue(4)
        self.grid_background = QLineEdit("#151515")
        color = QPushButton("背景色")
        color.clicked.connect(self.choose_grid_color)
        self.grid_border = QCheckBox("添加边框")
        self.grid_border.setChecked(True)
        row.addWidget(self.batch_grid)
        row.addWidget(QLabel("间距"))
        row.addWidget(self.grid_gap)
        row.addWidget(self.grid_background)
        row.addWidget(color)
        row.addWidget(self.grid_border)
        layout.addLayout(row)
        button = QPushButton("批量生成")
        button.setObjectName("primaryButton")
        button.clicked.connect(self.generate_batch)
        layout.addWidget(button)
        layout.addStretch()
        return page

    def _build_gui_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        self.gui_template = QComboBox()
        self.gui_template.addItems(MC_GUI_TEMPLATES.keys())
        self.gui_title = QLineEdit("工业机器")
        self.gui_slots = QSpinBox()
        self.gui_slots.setRange(0, 54)
        self.gui_slots.setValue(8)
        self.gui_resolution = QComboBox()
        self.gui_resolution.addItems(["256", "512"])
        form = QFormLayout()
        form.addRow("预制模板", self.gui_template)
        form.addRow("界面标题", self.gui_title)
        form.addRow("槽位数量", self.gui_slots)
        form.addRow("输出尺寸", self.gui_resolution)
        layout.addLayout(form)
        button = QPushButton("生成 MC GUI 元素")
        button.setObjectName("primaryButton")
        button.clicked.connect(self.generate_gui)
        layout.addWidget(button)
        layout.addStretch()
        return page

    def _apply_theme(self) -> None:
        QApplication.instance().setStyle("Fusion")
        self.setStyleSheet(
            """
            * { font-family: "Microsoft YaHei UI", "Segoe UI"; }
            QMainWindow, QWidget { background: #0b0d10; color: #f3f5f8; }
            QFrame#leftPanel, QFrame#rightPanel { background: #171717; border: 1px solid #303030; border-radius: 14px; }
            QLabel#appBrand { font-size: 25px; font-weight: 900; letter-spacing: 1px; }
            QLabel#appSubtitle { color: #a5adba; font-size: 11px; font-weight: 700; letter-spacing: 1px; }
            QLabel#panelTitle { font-size: 21px; font-weight: 800; padding: 4px 2px; }
            QLabel#sectionTitle { font-weight: 700; }
            QTabBar::tab { background: #2a3114; padding: 10px 30px; min-width: 120px; }
            QTabBar::tab:selected { background: #050505; color: #e0ff00; }
            QLineEdit, QPlainTextEdit, QComboBox, QSpinBox, QListWidget {
              background: #080808; border: 1px solid #454545; border-radius: 8px; padding: 8px;
            }
            QPushButton { background: #202020; border: 1px solid #4b4b4b; border-radius: 8px; padding: 9px 14px; font-weight: 700; }
            QPushButton:hover { background: #303030; }
            QPushButton#primaryButton { background: #cfff00; color: #080808; border-color: #dfff33; }
            QPushButton#primaryButton:hover { background: #e0ff22; }
            QPushButton#settingsButton { background: #252b16; color: #e0ff22; border-color: #617313; }
            QStatusBar { background: #111; border-top: 1px solid #303030; }
            QProgressBar { border: 1px solid #465020; border-radius: 6px; text-align: center; background: #080808; min-height: 18px; }
            QProgressBar::chunk { border-radius: 5px; background: #cfff00; }
            """
        )

    def _start_mcp_if_enabled(self) -> None:
        if self.config.mcp_enabled:
            try:
                self.mcp.start(self.config.mcp_port)
                self.status.showMessage(f"MCP 本地服务：127.0.0.1:{self.config.mcp_port} · /docs")
            except Exception as exc:  # noqa: BLE001
                self.status.showMessage(f"MCP 启动失败：{exc}")
        else:
            self.status.showMessage("MCP 服务已关闭")

    def open_settings(self) -> None:
        dialog = SettingsDialog(self.config, self)
        if dialog.exec():
            dialog.apply_to(self.config)
            self.config_store.save(self.config)
            self.status.showMessage("设置已保存；MCP 端口或开关变更将在下次启动时完整生效。")

    def edit_templates(self) -> None:
        dialog = TemplateDialog(self.config, self)
        if dialog.exec():
            self.config_store.save(self.config)
            self.style.clear()
            self.style.addItems(self.config.templates.keys())

    def choose_grid_color(self) -> None:
        color = QColorDialog.getColor(parent=self)
        if color.isValid():
            self.grid_background.setText(color.name())

    def _run(self, operation, running_text: str) -> None:
        if self.thread:
            return
        self.progress_bar.setValue(0)
        self.progress_label.setText("0% · 正在排队")
        self.status.showMessage(running_text)
        self.thread = QThread(self)
        self.worker = Worker(operation)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.done.connect(self._finished)
        self.worker.error.connect(self._failed)
        self.worker.progress.connect(self._progress_updated)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self._thread_finished)
        self.thread.start()

    def _options(self, prompt: str, mode: str = "image", count: int = 1, texture_size: int = 32) -> GenerationOptions:
        return GenerationOptions(
            prompt=prompt, model=self.model.currentText().strip() or self.config.model,
            aspect_ratio=self.aspect.currentText(), resolution=self.resolution.currentText(), style=self.style.currentText(),
            count=count, mode=mode, texture_size=texture_size, output_dir=self.config.output_dir,
            custom_size=self.custom_size.text().strip(),
        )

    def generate_current(self) -> None:
        if len(self.prompt.toPlainText()) > 20_000:
            QMessageBox.warning(self, APP_NAME, "提示词不能超过 20000 字符。")
            return
        options = self._options(self.prompt.toPlainText())
        self._run(lambda report: self._generate(options, report), "正在生成图片…")

    def generate_texture(self) -> None:
        options = self._options(self.texture_prompt.toPlainText(), "texture", texture_size=int(self.texture_size.currentText()))
        self._run(lambda report: self._generate(options, report), "正在生成 MC 贴图…")

    def choose_img2img_source(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "选择参考图片",
            "",
            "图片文件 (*.png *.jpg *.jpeg *.webp *.bmp)",
        )
        if path:
            self.img2img_source.setText(path)
            self.canvas.show_path(Path(path))

    def generate_image_to_image(self) -> None:
        if not self.img2img_source.text().strip():
            QMessageBox.warning(self, APP_NAME, "请先选择一张参考图片。")
            return
        options = self._options(self.img2img_prompt.toPlainText())
        options.source_image = self.img2img_source.text().strip()
        self._run(lambda report: self._generate(options, report), "正在根据参考图生成…")

    def generate_gui(self) -> None:
        template = MC_GUI_TEMPLATES[self.gui_template.currentText()]
        prompt = (
            f"{template}. Window title concept: {self.gui_title.text()}. "
            f"Include {self.gui_slots.value()} item slots, button and progress elements. "
            f"Target texture resolution {self.gui_resolution.currentText()}x{self.gui_resolution.currentText()}."
        )
        options = self._options(prompt)
        self._run(lambda report: self._generate(options, report), "正在生成 MC GUI…")

    def generate_batch(self) -> None:
        prompts = [line.strip() for line in self.batch_prompts.toPlainText().splitlines() if line.strip()][:25]
        if not prompts:
            QMessageBox.warning(self, APP_NAME, "请至少输入一条批量描述。")
            return
        def task(report):
            paths: list[Path] = []
            total = len(prompts)
            for index, prompt in enumerate(prompts, 1):
                start = int((index - 1) * 90 / total)
                span = max(1, int(90 / total))
                report(start, f"正在生成第 {index}/{total} 张图片")
                paths.extend(
                    self._generate(
                        self._options(prompt),
                        lambda percent, message, start=start, span=span, batch_index=index: report(
                            start + int(percent * span / 100),
                            f"第 {batch_index}/{total} 张：{message}",
                        ),
                    )
                )
            if self.batch_grid.isChecked():
                report(92, "正在拼接网格图片")
                target = Path(self.config.output_dir) / f"grid_{int(__import__('time').time())}.png"
                paths.append(make_grid(paths, target, 5, self.grid_gap.value(), self.grid_background.text(), self.grid_border.isChecked()))
            report(100, f"批量任务完成，共 {len(paths)} 张")
            return paths
        self._run(task, f"正在批量生成 {len(prompts)} 张图片…")

    def _generate(self, options: GenerationOptions, report=None) -> list[Path]:
        paths = ImageApiClient(self.config).generate(options, report)
        for path in paths:
            self.history.add(options.prompt, {"mode": options.mode, "model": options.model, "style": options.style}, path)
        return paths

    @Slot(list)
    def _finished(self, paths: list[Path]) -> None:
        self.generated = paths
        self.clear_preview()
        for index, path in enumerate(paths):
            button = QPushButton(path.name)
            button.clicked.connect(lambda checked=False, selected=path: self.canvas.show_path(selected))
            self.thumb_layout.addWidget(button, index // 3, index % 3)
        if paths:
            self.canvas.show_path(paths[-1])
        self.refresh_history()
        self.progress_bar.setValue(100)
        self.progress_label.setText(f"100% · 已完成 {len(paths)} 张")
        self.status.showMessage(f"完成：生成 {len(paths)} 张图片。")

    @Slot(str)
    def _failed(self, message: str) -> None:
        self.progress_label.setText("失败")
        self.status.showMessage("生成失败")
        QMessageBox.critical(self, APP_NAME, message)

    @Slot(int, str)
    def _progress_updated(self, percent: int, message: str) -> None:
        self.progress_bar.setValue(percent)
        self.progress_label.setText(f"{percent}% · {message}")
        self.status.showMessage(message)

    @Slot()
    def _thread_finished(self) -> None:
        if self.thread:
            self.thread.deleteLater()
        self.thread = None
        self.worker = None

    def clear_preview(self) -> None:
        while self.thumb_layout.count():
            item = self.thumb_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def save_current_preview(self) -> None:
        if not self.generated:
            return
        target, _ = QFileDialog.getSaveFileName(self, "保存当前图片", self.generated[-1].name, "PNG (*.png)")
        if target:
            Path(target).write_bytes(self.generated[-1].read_bytes())

    def refresh_history(self) -> None:
        self.history_list.clear()
        for item in self.history.list():
            self.history_list.addItem(f"{item['created_at']} · {item['prompt'][:72]} · {Path(item['image_path']).name}")

    def _history_clicked(self, item) -> None:
        selected = self.history.list()[self.history_list.row(item)]
        path = Path(selected["image_path"])
        if path.exists():
            self.canvas.show_path(path)

    def import_prompts(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "导入提示词", "", "CSV/JSON (*.csv *.json)")
        if not path:
            return
        source = Path(path)
        try:
            if source.suffix.lower() == ".json":
                data = json.loads(source.read_text(encoding="utf-8"))
                prompts = [entry.get("prompt", "") if isinstance(entry, dict) else str(entry) for entry in data]
            else:
                with source.open(encoding="utf-8-sig", newline="") as file:
                    prompts = [row.get("prompt", next(iter(row.values()), "")) for row in csv.DictReader(file)]
            self.batch_prompts.setPlainText("\n".join(prompt for prompt in prompts if prompt))
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, APP_NAME, f"导入失败：{exc}")

    def export_history_json(self) -> None:
        target, _ = QFileDialog.getSaveFileName(self, "导出历史 JSON", "history.json", "JSON (*.json)")
        if target:
            self.history.export_json(Path(target))

    def export_history_csv(self) -> None:
        target, _ = QFileDialog.getSaveFileName(self, "导出历史 CSV", "history.csv", "CSV (*.csv)")
        if target:
            self.history.export_csv(Path(target))

    def closeEvent(self, event) -> None:
        self.mcp.stop()
        super().closeEvent(event)
