"""Generate the multi-resolution UltraTexture Studio Windows application icon."""

from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter


ROOT = Path(__file__).resolve().parent
ICON_PATH = ROOT / "icon.ico"


def panel(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], radius: int, fill, outline=None, width=1) -> None:
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def make_icon() -> Image.Image:
    image = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
    glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
    glow_draw = ImageDraw.Draw(glow)
    glow_draw.ellipse((38, 34, 218, 214), fill=(145, 236, 43, 54))
    image.alpha_composite(glow.filter(ImageFilter.GaussianBlur(18)))

    draw = ImageDraw.Draw(image)
    panel(draw, (12, 12, 244, 244), 46, (10, 15, 19, 255), (100, 123, 47, 255), 8)
    panel(draw, (24, 24, 232, 232), 35, (18, 27, 32, 255), (48, 76, 80, 255), 3)

    # Minecraft-like background grid.
    for y in range(38, 212, 28):
        for x in range(38, 212, 28):
            color = (29, 43, 48, 255) if (x + y) // 28 % 2 else (23, 36, 41, 255)
            panel(draw, (x, y, x + 19, y + 19), 4, color)

    cyan, cyan_light = (80, 214, 255, 255), (180, 244, 255, 255)
    lime, lime_dark, charcoal = (207, 255, 0, 255), (104, 142, 19, 255), (8, 13, 16, 255)
    panel(draw, (52, 62, 204, 198), 21, charcoal, (57, 88, 89, 255), 4)
    panel(draw, (59, 74, 81, 177), 8, lime_dark)
    panel(draw, (175, 74, 197, 177), 8, lime_dark)
    panel(draw, (65, 80, 76, 166), 5, lime)
    panel(draw, (180, 80, 191, 166), 5, lime)

    # Thick U monogram and a top energy/tool bar: recognizable in a 16px title bar.
    panel(draw, (91, 72, 113, 151), 7, cyan)
    panel(draw, (143, 72, 165, 151), 7, cyan)
    panel(draw, (104, 132, 152, 157), 8, cyan)
    panel(draw, (112, 80, 121, 140), 4, cyan_light)
    panel(draw, (80, 55, 176, 76), 7, lime)
    panel(draw, (119, 49, 137, 112), 7, lime)
    panel(draw, (125, 57, 132, 103), 3, (246, 255, 190, 255))

    for x, color in ((86, lime), (118, cyan), (150, lime)):
        panel(draw, (x, 177, x + 18, 187), 4, color)
    return image


if __name__ == "__main__":
    make_icon().save(
        ICON_PATH,
        format="ICO",
        sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )
    print(f"Created {ICON_PATH}")
