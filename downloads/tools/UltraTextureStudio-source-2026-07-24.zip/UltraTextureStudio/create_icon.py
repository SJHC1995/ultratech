"""Build the multi-resolution Windows icon from the approved Studio artwork."""

from pathlib import Path

from PIL import Image, ImageOps


ROOT = Path(__file__).resolve().parent
SOURCE_LOGO = ROOT / "assets" / "ultratexture_studio_logo.png"
ICON_PATH = ROOT / "icon.ico"


def make_icon() -> Image.Image:
    if not SOURCE_LOGO.is_file():
        raise FileNotFoundError(f"Missing approved icon artwork: {SOURCE_LOGO}")
    with Image.open(SOURCE_LOGO) as source:
        return ImageOps.fit(
            source.convert("RGBA"),
            (256, 256),
            method=Image.Resampling.LANCZOS,
            centering=(0.5, 0.5),
        )


if __name__ == "__main__":
    make_icon().save(
        ICON_PATH,
        format="ICO",
        sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )
    print(f"Created {ICON_PATH}")
