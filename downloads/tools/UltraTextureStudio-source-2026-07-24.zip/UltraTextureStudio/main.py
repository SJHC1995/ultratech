from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from ultratexture.core import APP_NAME, configure_logging
from ultratexture.ui import MainWindow


def resource_path(name: str) -> Path:
    """Resolve a bundled file when packaged, or a source file during development."""
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) / name


def main() -> int:
    configure_logging()
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setWindowIcon(QIcon(str(resource_path("icon.ico"))))
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
