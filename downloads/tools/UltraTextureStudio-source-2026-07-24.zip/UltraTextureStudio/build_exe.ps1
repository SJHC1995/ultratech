param(
  [string]$Python = "C:\Users\Administrator\AppData\Local\Programs\Python\Python312\python.exe"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path $Python)) {
  throw "Python not found: $Python"
}

Push-Location $root
try {
  & $Python -m pip install -r requirements.txt
  if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed." }

  & $Python -m PyInstaller `
    --noconfirm `
    --clean `
    --windowed `
    --onefile `
    --name UltraTextureStudio `
    --icon icon.ico `
    --add-data "icon.ico;." `
    main.py
  if ($LASTEXITCODE -ne 0) { throw "PyInstaller build failed." }

  Write-Output "EXE created: $root\dist\UltraTextureStudio.exe"
}
finally {
  Pop-Location
}
