@echo off
setlocal
set PYTHON=C:\Users\Administrator\AppData\Local\Programs\Python\Python312\python.exe
if not exist "%PYTHON%" (
  echo Python not found: %PYTHON%
  exit /b 1
)
powershell -ExecutionPolicy Bypass -File "%~dp0build_exe.ps1" -Python "%PYTHON%"
endlocal
