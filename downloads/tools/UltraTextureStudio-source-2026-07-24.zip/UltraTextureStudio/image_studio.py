"""Image Studio - configurable OpenAI-compatible image generation desktop app."""

from __future__ import annotations

import base64
import json
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import requests
from PySide6.QtCore import QObject, QSettings, QSize, Qt, QThread, QUrl, Signal, Slot
from PySide6.QtGui import QAction, QDesktopServices, QIcon, QImage, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QVBoxLayout,
    QWidget,
)


APP_NAME = "Image Studio"
DEFAULT_ENDPOINT = "https://api.openai.com/v1"
DEFAULT_MODEL = "gpt-image-1"


def app_data_directory() -> Path:
    directory = Path.home() / "AppData" / "Roaming" / "ImageStudio"
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def default_output_directory() -> Path:
    directory = Path.home() / "Pictures" / "Image Studio"
    directory.mkdir(parents=True, exist_ok=True)
    return directory


@dataclass(frozen=True)
class GenerationRequest:
    endpoint: str
    api_key: str
    model: str
    prompt: str
    size: str
    quality: str
    count: int
    output_dir: Path


class ImageGeneratorWorker(QObject):
    completed = Signal(list)
    failed = Signal(str)
    finished = Signal()

    def __init__(self, request_data: GenerationRequest) -> None:
        super().__init__()
        self.request_data = request_data

    @Slot()
    def run(self) -> None:
        try:
            generated = self._generate()
            self.completed.emit(generated)
        except Exception as exc:  # noqa: BLE001 - displayed to the desktop user.
            self.failed.emit(str(exc))
        finally:
            self.finished.emit()

    def _generate(self) -> list[Path]:
        request_data = self.request_data
        endpoint = request_data.endpoint.rstrip("/")
        if not endpoint.endswith("/v1"):
            endpoint = f"{endpoint}/v1"

        payload: dict[str, object] = {
            "model": request_data.model,
            "prompt": request_data.prompt,
            "size": request_data.size,
            "n": request_data.count,
            "response_format": "b64_json",
        }
        if request_data.quality != "auto":
            payload["quality"] = request_data.quality

        response = requests.post(
            f"{endpoint}/images/generations",
            headers={
                "Authorization": f"Bearer {request_data.api_key}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=180,
        )
        if not response.ok:
            try:
                details = response.json().get("error", {}).get("message", response.text)
            except ValueError:
                details = response.text
            raise RuntimeError(f"API 请求失败（HTTP {response.status_code}）：{details[:900]}")

        body = response.json()
        images = body.get("data")
        if not isinstance(images, list) or not images:
            raise RuntimeError("API 返回中没有图像数据。请检查接口地址、模型名称和供应商兼容性。")

        created: list[Path] = []
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        for index, image_payload in enumerate(images, start=1):
            if "b64_json" in image_payload:
                binary = base64.b64decode(image_payload["b64_json"])
            elif "url" in image_payload:
                image_response = requests.get(image_payload["url"], timeout=180)
                image_response.raise_for_status()
                binary = image_response.content
            else:
                raise RuntimeError("API 图像条目既不包含 b64_json，也不包含 url。")

            target = request_data.output_dir / f"image-{timestamp}-{index}.png"
            target.write_bytes(binary)
            created.append(target)
        return created


class ImagePreviewCard(QFrame):
    def __init__(self, image_path: Path) -> None:
        super().__init__()
        self.image_path = image_path
        self.setObjectName("previewCard")
        self.setMinimumWidth(260)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        image = QImage(str(image_path))
        image_label = QLabel()
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        image_label.setMinimumSize(QSize(220, 220))
        image_label.setScaledContents(False)
        pixmap = QPixmap.fromImage(image)
        image_label.setPixmap(
            pixmap.scaled(420, 420, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        )

        name_label = QLabel(image_path.name)
        name_label.setObjectName("fileName")
        name_label.setWordWrap(True)
        open_button = QPushButton("打开文件")
        open_button.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(image_path))))

        layout.addWidget(image_label)
        layout.addWidget(name_label)
        layout.addWidget(open_button)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.settings = QSettings("UltraTechTools", "ImageStudio")
        self.thread: QThread | None = None
        self.worker: ImageGeneratorWorker | None = None

        self.setWindowTitle("Image Studio · API 图像生成器")
        self.setMinimumSize(1120, 760)
        self.resize(1320, 860)
        self._build_ui()
        self._restore_settings()

    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root_layout = QVBoxLayout(central)
        root_layout.setContentsMargins(20, 20, 20, 20)
        root_layout.setSpacing(16)

        title_row = QHBoxLayout()
        title_box = QVBoxLayout()
        eyebrow = QLabel("LOCAL DESKTOP TOOL")
        eyebrow.setObjectName("eyebrow")
        title = QLabel("Image Studio")
        title.setObjectName("title")
        subtitle = QLabel("配置 OpenAI 兼容图像接口，生成后直接保存 PNG。API Key 仅保留在本次运行内。")
        subtitle.setObjectName("subtitle")
        title_box.addWidget(eyebrow)
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        title_row.addLayout(title_box)
        title_row.addStretch()

        self.open_output_button = QPushButton("打开输出文件夹")
        self.open_output_button.clicked.connect(self._open_output_folder)
        title_row.addWidget(self.open_output_button)
        root_layout.addLayout(title_row)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        root_layout.addWidget(splitter, 1)

        controls = QFrame()
        controls.setObjectName("controlsPanel")
        controls.setMinimumWidth(360)
        controls_layout = QVBoxLayout(controls)
        controls_layout.setContentsMargins(18, 18, 18, 18)
        controls_layout.setSpacing(14)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        form.setVerticalSpacing(10)

        self.endpoint_input = QLineEdit()
        self.endpoint_input.setPlaceholderText(DEFAULT_ENDPOINT)
        self.model_input = QLineEdit()
        self.model_input.setPlaceholderText(DEFAULT_MODEL)
        self.api_key_input = QLineEdit()
        self.api_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key_input.setPlaceholderText("粘贴 API Key（不会写入配置文件）")
        self.reveal_key = QCheckBox("显示 Key")
        self.reveal_key.toggled.connect(
            lambda checked: self.api_key_input.setEchoMode(
                QLineEdit.EchoMode.Normal if checked else QLineEdit.EchoMode.Password
            )
        )

        self.size_input = QComboBox()
        self.size_input.addItems(["1024x1024", "1024x1536", "1536x1024"])
        self.quality_input = QComboBox()
        self.quality_input.addItems(["auto", "low", "medium", "high"])
        self.count_input = QSpinBox()
        self.count_input.setRange(1, 4)
        self.count_input.setValue(1)

        self.output_input = QLineEdit()
        choose_output = QPushButton("选择…")
        choose_output.clicked.connect(self._choose_output_folder)
        output_row = QHBoxLayout()
        output_row.addWidget(self.output_input, 1)
        output_row.addWidget(choose_output)

        form.addRow("接口基础地址", self.endpoint_input)
        form.addRow("图像模型", self.model_input)
        form.addRow("API Key", self.api_key_input)
        form.addRow("", self.reveal_key)
        form.addRow("尺寸", self.size_input)
        form.addRow("质量", self.quality_input)
        form.addRow("生成数量", self.count_input)
        form.addRow("输出目录", output_row)
        controls_layout.addLayout(form)

        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        controls_layout.addWidget(separator)
        controls_layout.addWidget(QLabel("提示词"))

        self.prompt_input = QPlainTextEdit()
        self.prompt_input.setPlaceholderText(
            "例：cinematic industrial research lab, teal control panels, volumetric lighting, highly detailed"
        )
        self.prompt_input.setMinimumHeight(220)
        controls_layout.addWidget(self.prompt_input)

        self.generate_button = QPushButton("生成图像")
        self.generate_button.setObjectName("generateButton")
        self.generate_button.clicked.connect(self._start_generation)
        controls_layout.addWidget(self.generate_button)
        self.status_label = QLabel("就绪")
        self.status_label.setObjectName("status")
        self.status_label.setWordWrap(True)
        controls_layout.addWidget(self.status_label)
        controls_layout.addStretch()

        preview_scroll = QScrollArea()
        preview_scroll.setWidgetResizable(True)
        preview_scroll.setObjectName("previewScroll")
        preview_container = QWidget()
        self.preview_layout = QGridLayout(preview_container)
        self.preview_layout.setContentsMargins(20, 20, 20, 20)
        self.preview_layout.setSpacing(16)
        self.empty_label = QLabel("生成的图像会显示在这里")
        self.empty_label.setObjectName("emptyPreview")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_layout.addWidget(self.empty_label, 0, 0, 1, 2)
        preview_scroll.setWidget(preview_container)

        splitter.addWidget(controls)
        splitter.addWidget(preview_scroll)
        splitter.setSizes([430, 890])

        clear_action = QAction("清空预览", self)
        clear_action.triggered.connect(self._clear_previews)
        self.addAction(clear_action)

    def _restore_settings(self) -> None:
        self.endpoint_input.setText(self.settings.value("endpoint", DEFAULT_ENDPOINT))
        self.model_input.setText(self.settings.value("model", DEFAULT_MODEL))
        self.output_input.setText(self.settings.value("output", str(default_output_directory())))
        size = self.settings.value("size", "1024x1024")
        quality = self.settings.value("quality", "auto")
        self.size_input.setCurrentText(size)
        self.quality_input.setCurrentText(quality)
        self.count_input.setValue(int(self.settings.value("count", 1)))

    def _save_non_secret_settings(self) -> None:
        self.settings.setValue("endpoint", self.endpoint_input.text().strip())
        self.settings.setValue("model", self.model_input.text().strip())
        self.settings.setValue("output", self.output_input.text().strip())
        self.settings.setValue("size", self.size_input.currentText())
        self.settings.setValue("quality", self.quality_input.currentText())
        self.settings.setValue("count", self.count_input.value())

    def _choose_output_folder(self) -> None:
        chosen = QFileDialog.getExistingDirectory(self, "选择图像输出目录", self.output_input.text())
        if chosen:
            self.output_input.setText(chosen)

    def _open_output_folder(self) -> None:
        output_dir = Path(self.output_input.text().strip() or default_output_directory())
        output_dir.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(output_dir)))

    def _clear_previews(self) -> None:
        while self.preview_layout.count():
            item = self.preview_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self.empty_label = QLabel("生成的图像会显示在这里")
        self.empty_label.setObjectName("emptyPreview")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_layout.addWidget(self.empty_label, 0, 0, 1, 2)

    def _start_generation(self) -> None:
        endpoint = self.endpoint_input.text().strip()
        api_key = self.api_key_input.text().strip()
        model = self.model_input.text().strip()
        prompt = self.prompt_input.toPlainText().strip()
        output_dir = Path(self.output_input.text().strip())

        if not endpoint or not api_key or not model or not prompt:
            QMessageBox.warning(self, APP_NAME, "请填写接口地址、API Key、模型名称和提示词。")
            return

        try:
            output_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            QMessageBox.warning(self, APP_NAME, f"无法创建输出目录：{exc}")
            return

        self._save_non_secret_settings()
        request_data = GenerationRequest(
            endpoint=endpoint,
            api_key=api_key,
            model=model,
            prompt=prompt,
            size=self.size_input.currentText(),
            quality=self.quality_input.currentText(),
            count=self.count_input.value(),
            output_dir=output_dir,
        )

        self.generate_button.setEnabled(False)
        self.status_label.setText("正在请求图像生成服务，请稍候…")
        self.thread = QThread(self)
        self.worker = ImageGeneratorWorker(request_data)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.completed.connect(self._on_generation_complete)
        self.worker.failed.connect(self._on_generation_failed)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self._on_thread_finished)
        self.thread.start()

    @Slot(list)
    def _on_generation_complete(self, files: list[Path]) -> None:
        self._clear_previews()
        for index, image_path in enumerate(files):
            card = ImagePreviewCard(image_path)
            self.preview_layout.addWidget(card, index // 2, index % 2)
        self.status_label.setText(f"完成：已保存 {len(files)} 张 PNG 到 {files[0].parent}")

    @Slot(str)
    def _on_generation_failed(self, message: str) -> None:
        self.status_label.setText("生成失败")
        QMessageBox.critical(self, APP_NAME, message)

    @Slot()
    def _on_thread_finished(self) -> None:
        self.generate_button.setEnabled(True)
        if self.thread:
            self.thread.deleteLater()
        self.thread = None
        self.worker = None


def apply_theme(app: QApplication) -> None:
    app.setStyle("Fusion")
    app.setStyleSheet(
        """
        * { font-family: "Microsoft YaHei UI", "Segoe UI", sans-serif; }
        QMainWindow, QWidget { background: #10141d; color: #eef4ff; }
        QFrame#controlsPanel, QFrame#previewCard {
            background: #171d29; border: 1px solid #29364a; border-radius: 14px;
        }
        QLabel#eyebrow { color: #71d7ff; font-size: 11px; font-weight: 700; letter-spacing: 2px; }
        QLabel#title { color: #ffffff; font-size: 34px; font-weight: 700; }
        QLabel#subtitle, QLabel#status, QLabel#fileName { color: #aab7ca; }
        QLabel#emptyPreview { color: #7f8ca0; font-size: 18px; }
        QLineEdit, QPlainTextEdit, QComboBox, QSpinBox {
            background: #0f141e; border: 1px solid #334359; border-radius: 8px;
            padding: 8px; selection-background-color: #287ea9;
        }
        QLineEdit:focus, QPlainTextEdit:focus, QComboBox:focus, QSpinBox:focus {
            border: 1px solid #64d6ff;
        }
        QPushButton {
            background: #233047; border: 1px solid #3b4d68; border-radius: 8px;
            padding: 9px 14px; font-weight: 600;
        }
        QPushButton:hover { background: #2c3d59; }
        QPushButton:disabled { color: #7c8797; background: #1b2230; }
        QPushButton#generateButton { background: #1683b4; border-color: #67d7ff; color: white; font-size: 15px; }
        QPushButton#generateButton:hover { background: #1b9cd2; }
        QScrollArea#previewScroll { border: 1px solid #29364a; border-radius: 14px; background: #121824; }
        QScrollArea#previewScroll > QWidget > QWidget { background: #121824; }
        QFrame[frameShape="4"] { color: #29364a; }
        """
    )


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("UltraTechTools")
    apply_theme(app)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
