# UltraTexture Studio

面向 Minecraft 资源包、批量拼图和 MC GUI 的本地图像生成工作台。

## 主要功能

- OpenAI 兼容图像接口：可配置 API Key、Base URL、模型、代理、User-Agent 和输出目录。
- 请求兼容模式：支持 OpenAI 标准请求，以及 AiMaMi 同款最简 JSON 请求；后者仅传递
  `model`、`prompt`、`n`、`size`，图生图使用同一生成地址的 `image` Base64 data URL 字段。
- 文生图：模型、宽高比、1K/2K/4K/8K、可编辑风格预制。
- 图生图：选择本地参考图和重绘描述，自动调用兼容接口的 `/v1/images/edits` multipart 上传接口。
- MC 纹理模式：16×16、32×32、64×64 目标贴图；服务生成后会使用最近邻算法自动输出实际尺寸 PNG，文件名为“纹理名称_尺寸.png”。
- 批量生成：最多 25 条描述；支持 CSV/JSON 导入与 5×5 拼图。
- MC GUI：背包、熔炉、工作台、机器界面预制，支持槽位数和输出尺寸。
- SQLite 历史记录、PNG 预览、JSON/CSV 历史导出。
- 本地 FastAPI MCP Bridge：默认 `127.0.0.1:8765`，Swagger 文档为 `/docs`。

## API 兼容性

默认使用 OpenAI 兼容的 `POST /v1/images/generations` 负载。不同供应商支持的
模型、宽高比、尺寸、数量和质量字段可能不同；请按供应商文档在设置中调整。

默认情况下，生成图片会自动保存到程序安装目录下的 `.cache\` 文件夹。可在“设置”
中改为其他目录。API Key、配置、历史、日志都只保存在本机：

`%APPDATA%\UltraTextureStudio\`

若上游服务在 Cloudflare 后面，可在“设置 → User-Agent”填写服务商要求的请求头值；
程序会在文生图、图生图、批量、MC 纹理和 MCP 请求中统一传递该值。

## MCP / HTTP 接口

| 路由 | 作用 |
|---|---|
| `GET /health` | 健康状态 |
| `POST /generate` | 单次图像生成 |
| `POST /generate_texture` | MC 纹理生成 |
| `POST /generate_batch` | 批量生成 |
| `POST /generate_grid` | 批量生成后拼图 |
| `POST /mcp` | 本地 JSON-RPC MCP Bridge（`initialize`、`tools/list`、`tools/call`） |
| `GET /docs` | Swagger/OpenAPI 文档 |

`mcp.json.example` 是本地 HTTP MCP 配置示例。

## 从源码运行

```powershell
C:\Users\Administrator\AppData\Local\Programs\Python\Python312\python.exe -m pip install -r requirements.txt
C:\Users\Administrator\AppData\Local\Programs\Python\Python312\python.exe main.py
```

## 打包

```powershell
.\build_exe.ps1
```

或双击：

```text
build.bat
```

产物：

`dist\UltraTextureStudio.exe`

## 已知限制 / TODO

- 兼容 API 对 2K/4K/8K、批次数和 `response_format` 的支持并不统一。
- “MC GUI”当前通过结构化提示词生成贴图；若需像素级槽位编辑器，可在后续
  增加本地画布与图层导出。
- `/mcp` 提供本地 JSON-RPC bridge；若目标 Codex 客户端只接受特定 MCP
  transport，使用其 HTTP connector 指向该端点，或将路由转接到标准 MCP
  网关。
